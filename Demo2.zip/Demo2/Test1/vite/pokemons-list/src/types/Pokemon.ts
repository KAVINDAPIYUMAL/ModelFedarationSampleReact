export interface IPokemon {
  id: number;
  name: string;
  sprite: string;
}
