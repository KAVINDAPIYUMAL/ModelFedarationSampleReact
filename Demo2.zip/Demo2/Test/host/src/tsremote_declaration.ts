declare module 'remoteApp/*'
